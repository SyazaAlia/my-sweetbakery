  <?php

  $db = mysqli_connect("localhost","root","","order");

  if(isset($_POST['submit'])){
  	
  	$dtime = date('Y-m-d', strtotime($_POST['dtime']));
  	$dtime2 = date('Y-m-d', strtotime($_POST['dtime2']));
  	$usr_time = date('H:i:s',strtotime($_POST['usr_time']));
  	$usr_time2 = date('H:i:s',strtotime($_POST['usr_time2']));

    if(!$dtime){
    	echo $dtime;
    }else{
    	$query = "INSERT INTO order (dtime,drop_date,pick_time,drop_time) VALUES ('$dtime','$dtime2','$usr_time','$usr_time2')";
    	$run_query=mysqli_query($db,$query);

    	if($run_query){
    		 header("Location: orderdetail.php");
    	}else{
    		echo "greska!!!!!";

    	}

    }

  }