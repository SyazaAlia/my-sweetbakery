<?php

$cake_id = $_GET["id"];
echo "my cake ID IS $cake_id";

?>