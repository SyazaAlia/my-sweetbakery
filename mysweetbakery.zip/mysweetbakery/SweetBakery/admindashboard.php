<?php
require('admindb.php');
include("adminauth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Dashboard </title>
<link rel="stylesheet" href="style.css" />
</head>
<body>
<div class="form">
<p>Dashboard</p>
<p>MY SWEET BAKERY</p>
<p><a href="adminindex.php">Home</a></p>
<p><a href="insert.php">Insert Cake</a></p>
<p><a href="view.php">View Cake</a><p>
<p><a href="viewuser.php">View Customer</a><p>
<p><a href="vieworder.php">View Order</a><p>
<a href="adminlogout.php">Logout</a>
</div>
</body>
</html>