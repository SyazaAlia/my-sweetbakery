<?php
require('orderdb.php');

$order_id=$_REQUEST['order_id'];
$query = "DELETE FROM order_detail WHERE order_id=$order_id"; 
$result = mysqli_query($con,$query) or die ( mysqli_error());
header("Location: vieworder.php"); 
?>