<?php
session_start();

 
$cake_id = $_GET["id"];
include('cakedb.php');

//SET DATE
$currentDate = date("d-m-Y");

//pickupDate
$pickupDate = date('d-m-Y', strtotime($currentDate . ' +5 day'));


//select cake
$query = "Select * from cake where id=$cake_id;";
$result = mysqli_query($con,$query);
while($row = mysqli_fetch_assoc($result)) {
		$cakename = $row["cakename"];
		$cakeprice = $row["cakeprice"];

}
?>




<!DOCTYPE html>

<html>
<head>
  <title>Order Form</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script type="text/javascript" src="js/jquery.js"></script>
</head>
	<tr>
        <td>
          <label>Customer Name</label>
          <input type="text" name="<?php echo $_SESSION['username']; ?>" class="form-control username" value="<?php echo $_SESSION['username']; ?>" readonly>
          </td>
  <!Doctype html>
<html lang="en">
<head>
<meta charset="ut-8">
<title>jQuery UI Datepicker- Default functionality</title>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="css/style.css">
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
<link rel="stylesheet"  href="style.css">
<script >
$(function(){
  $("#datepicker").datepicker();
  $("#datepicker2").datepicker();
  
});
</script>
</head>
<body>

  <form action="orderconfirm.php?cake_id=<?php echo "$cake_id"; ?>" method="POST">

  Date Order:<br>
  <td><input type="date" name="dateorder" value="<?php echo "$currentDate";?>" readonly><td></br>

  Date Pickup:<br>
  <td><input type="date" name="datepickup" value ="<?php echo "$pickupDate";?> " readonly><td></br>
 



      

     

      </tr>
    </table>
    <hr style="border:1px dashed black">
    <table class="table table-hover">
      <thead>
        <tr>
          
          <th>Cake</th>
          <th>Quantity</th>
          <th>Price</th>
          <th>Amount</th>
        
        </tr>
      </thead>
      <tbody class="details">
          <tr> 
          	   
               <td><input type="text" name="<?php echo "$cakename"; ?>" class="form-control product_name" value="<?php echo "$cakename"; ?>" readonly></td>
               <td><input type="text" name="quantity" class="form-control quantity"></td>
               <td><input type="text" name="<?php echo "$cakeprice"; ?>" class="form-control cakeprice" value="<?php echo "$cakeprice"; ?>" readonly></td>
               <td><input type="text" name="amount" class="form-control amount"></td>
               <td><input type="button"  class="btn btn-danger remove" value="Remove"></td>
          </tr>
      </tbody>
      <tfoot>
        <tr>   
            <td></td>
            <td></td>
            <td></td>        
          <td>
            <label>Sub Total</label>
            <input type="text" name="" class="subtotal form-control">
            <input type="submit" class="btn btn-primary" name="order" value="Order Now">
          </td>
          <div class="form">

<p><a href="logout.php">Logout</a></p>
        </tr>
      </tfoot>
    </table>
  </form>
 </div>
</body>
</html>

<script type="text/javascript">
    

    function total()
    {
       var gg = 0;
       $('.amount').each(function(i,e){
          var amt = $(this).val()-0;
          gg += amt;
        });
       $('.subtotal').val(gg);
    }


  $(function(){


   

    // total amount 
    $('.details').delegate('.quantity,.cakeprice','keyup',function(){
      var tr = $(this).parent().parent();
      var cakeprice = tr.find('.cakeprice').val();
      var qty   = tr.find('.quantity').val();
      var amount = cakeprice * qty;
      tr.find('.amount').val(amount);
      total();
    });
    // end 


    // delete row 
    $('.details').delegate('.remove','click',function(){
        var con = confirm("Do you want to remove it ?");
        if(con)
        {
          $(this).parent().parent().remove();
          total();
        }

    });
    // end 


    //get pay
    $('.pay').change(function(){
      var subtotal = $('.subtotal').val()-0;
      var get      = $(this).val()-0;
      $('.return').val(get - subtotal);
    });
    // end 
  });
</script>