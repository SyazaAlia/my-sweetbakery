Database admin
CREATE TABLE IF NOT EXISTS `admin` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `username` varchar(50) NOT NULL,
 `email` varchar(50) NOT NULL,
 `password` varchar(50) NOT NULL,
 `trn_date` datetime NOT NULL,
 PRIMARY KEY (`id`)
 );
....................................................
....................................................
Database customer
CREATE TABLE IF NOT EXISTS `customer` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `username` varchar(50) NOT NULL,
 `email` varchar(50) NOT NULL,
 `password` varchar(50) NOT NULL,
 `trn_date` datetime NOT NULL,
 PRIMARY KEY (`id`)
 ..................................................
 ..................................................
 Database cake
 CREATE TABLE IF NOT EXISTS `cake` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `cakename` varchar(50) NOT NULL,
 `cakeprice`int(11) NOT NULL,
 `submittedby` varchar(50) NOT NULL,
 PRIMARY KEY (`id`)
 );
 ..................................................
 ..................................................
 Database order
 CREATE TABLE IF NOT EXISTS `order_detail` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `dateorder` date NOT NULL,
 `datepickup` date NOT NULL,
 `quantity` int(11) NOT NULL,
 `totalprice`int(11) NOT NULL,
 `cake_id` int(11) NOT NULL,
 `username` varchar(50) NOT NULL,
 PRIMARY KEY (`id`)
 );