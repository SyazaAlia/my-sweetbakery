





<?php
session_start();
?>

<!doctype html>
<body
background=" img/black5.jpg"

>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Home</title>

    <!-- Bootstrap Core CSS -->
    <link href="boost/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="boost/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="boost/vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="boost/css/creative.min.css" rel="stylesheet">

</head>


<body style="background-color:#5D6D7E  ;">


</body>
<body id="page-top">

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="home.php">Dream Car Rental</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a class="page-scroll" href="home.php">Home</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="adminlogin.php">Admin</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="userlogin.php">User</a>
                    </li>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
<head>
<meta charset="ut-8">
<title>jQuery UI Datepicker- Default functionality</title>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="css/style.css">
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
<link rel="stylesheet"  href="style.css">



<script >
$(function(){
	$("#datepicker").datepicker();
	$("#datepicker2").datepicker();

});
</script>
</head>

<body>
	<br><br><br><br>
	<form action="zakazivanje.php" method="POST">

        <center>
		Pickup Date:<br>
		<p><input type="text" id="datepicker" name="dtime"></p>
		 Select a time:
		  <input type="time" name="usr_time"><br>
		
		<br>Drop Off Date:<br>
		<p><input type="text" id="datepicker2" name="dtime2"></p>
		 Select a time:
		  <input type="time" name="usr_time2"><br><br>

 
   <input type="submit" name="submit" value="Search">
  </form>
<div class="form">
<p>Welcome <?php echo $_SESSION['username']; ?>!</p>

</div>

</center>

	</form>

</body>

